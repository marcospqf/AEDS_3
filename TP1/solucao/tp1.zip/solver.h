#ifndef xablau 
#define xablau
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "vector.h"
#include "dinic.h"

//resolve a instancia do main
void solve(int *franquias, int *clientes, graph *g, int f, int c, int n);
#endif
